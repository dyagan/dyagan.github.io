%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIXED-POINT MIRRLEES SIMULATIONS
%
% OBJECTIVE FUNCTION FOR FINDING OPTIMAL LABOR SUPPLY
% FP_opt_l_obj_.m
%
% Mankiw-Weinzierl-Yagan "Optimal Taxation in Theory and Practice"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function neg_utility = FP_opt_l_obj_(l_opt_i, i, w, y, tax_marg, transfer, gamma, alpha, sigma);

neg_utility = -( ( (FP_consump_(l_opt_i, i, w, y, tax_marg, transfer))^(1-gamma)-1 )/(1-gamma) - alpha/sigma*l_opt_i^(sigma) );

end