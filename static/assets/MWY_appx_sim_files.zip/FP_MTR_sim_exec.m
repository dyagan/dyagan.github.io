%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIXED-POINT MIRRLEES SIMULATIONS
%
% EXECUTION FILE
% FP_MTR_sim_exec.m
%
% Mankiw-Weinzierl-Yagan "Optimal Taxation in Theory and Practice"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


delete diary_FP_MTR_sim
diary diary_FP_MTR_sim;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SETUP

% SET FORMATS.
format long;
format compact;
warning off;

% LOAD DATA.
clear;
clc;
data = load('input_data.txt');
options=optimset('TolCon',1e-13,'TolFun',1e-13,'TolX',1e-13,'Display','off','MaxFunEvals',10000000,'MaxIter',200);

% INPUT WAGES AND CDF EVALUATED AT EACH WAGE. 
cdf_orig = data(:,2);
wage_orig = data(:,1);
clear data
wage_orig_min = min(wage_orig);
wage_orig_max = max(wage_orig);

% SET DISTRIBUTION PARAMETERS. BINS MUST BE EQUAL-SIZED.
num_wages = length(wage_orig)-1;
w = (wage_orig(1:num_wages)+wage_orig(2:num_wages+1)) / 2;
pmf = cdf_orig(2:num_wages+1) - cdf_orig(1:num_wages);
bin_width = w(2) - w(1);
wage_min = min(w);
wage_max = max(w);

% NORMALIZE THE PMF SO THAT ITS MASS EQUALS 1.
pmf = pmf./sum(pmf);

% CREATE CDF.
cdf = zeros(num_wages,1);
for k=1:num_wages
    cdf(k) = sum(pmf(1:k));
end

% CREATE pmf_over_bin_width FOR PLANNER'S FOC.
pmf_over_bin_width = pmf/bin_width;

% SET SIZE OF RELEVANT VECTORS.
y = zeros(num_wages,1);
c = zeros(num_wages,1);
l = zeros(num_wages,1);
tax_paid = zeros(num_wages,1);
IC_check = zeros(num_wages^2,1);
marg_soc_value_above_w = zeros(num_wages,1);
l_iters = zeros(num_wages,1000);
y_iters = zeros(num_wages,1000);
tax_marg_iters = zeros(num_wages,1000);

% SET UTILITY PARAMETERS.
gamma = 1.5;
alpha = 2.55;
sigma = 3;

% SET FMINCON GUESS, BOUNDS, AND LOOP TOLERANCES. tolerance_gov_bc IS IN
% UNITS OF PERCENT OF GNI. tolerance_tax_dev IS IN UNITS OF PERCENT
% DEVIATION OF THE NEW OPTIMAL TAX SCHEDULE AT EACH WAGE FROM THE PREVIOUS 
% ITERATION'S OPTIMAL TAX SCHEDULE.  
guess_for_lowest_wage = .1;
lb = 0;
ub = inf;
tolerance_gov_bc = .00001;
tolerance_tax_dev = .00001;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FIND THE FIXED-POINT TAX SCHEDULE

% STARTING PARAMETER VALUES.
tax_marg = .35*ones(num_wages,1);
tax_marg_iters(:,1) = tax_marg;
transfer = .000001;
loop = 0;
gov_imbalance_percent_gni = -9999999;
max_percent_opt_tax_deviation = -9999999;


% [LOOP]: WHILE THE GOVERNMENT BUDGET CONSTRAINT DEVIATES TOO MUCH FROM 
% EQUALITY OR THE TAX SCHEDULE HAS NOT SUFFICIENTLY CONVERGED TO A 
% FIXED-POINT, RUN THROUGH THE FOLLOWING LOOP: (1) GIVEN A TAX SCHEDULE AND
% A TRANSFER, FIND EACH WAGE'S OPTIMAL LABOR SUPPLY, (2) USE THE PLANNER'S 
% FOC TO FIND AN ALTERNATIVE TAX SCHEDULE GIVEN THE DERIVED LABOR SUPPLY 
% AND THE TRANSFER, (3) AVERAGE THE TWO SCHEDULES POINT-WISE TO YIELD A NEW
% TAX SCHEDULE, (4) FIND EACH WAGE'S OPTIMAL LABOR SUPPLY UNDER THE NEW TAX 
% SCHEDULE AND SET THE TRANSFER EQUAL TO RESULTING GOVERNMENT REVENUE.

while ( (abs(gov_imbalance_percent_gni)>tolerance_gov_bc) || (abs(max_percent_opt_tax_deviation)>tolerance_tax_dev) )
    loop = loop+1
    
    % FIND EACH PERSON'S OPTIMAL LABOR SUPPLY CONDITIONAL ON THE
    % TRANSFER AND THE MTR SCHEDULE.
    [l, y] = FP_find_opt_l_(num_wages, transfer, tax_marg, w, guess_for_lowest_wage, lb, ub, options, gamma, alpha, sigma);

    % CALCULATE UTILITY AT EACH WAGE.
    for i=1:num_wages
        c(i) = FP_consump_(l(i), i, w, y, tax_marg, transfer);
    end
    u = (c.^(1-gamma)-1)/(1-gamma) - alpha*l.^sigma/sigma;

    % CALCULATE COMPONENTS OF PLANNER'S FOC.
    elas_comp = 1 ./ (sigma-1+alpha*gamma*l.^sigma.*c.^(gamma-1)); 
    elas_uncomp = (1-alpha*gamma*l.^sigma.*c.^(gamma-1)) ./ (sigma-1+alpha*gamma*l.^sigma.*c.^(gamma-1));
    u_prime_c = c.^(-gamma);
    total_marg_soc_value = sum(pmf./u_prime_c);
    for k=1:num_wages
        marg_soc_value_above_w(k) = total_marg_soc_value - sum(pmf(1:k)./u_prime_c(1:k));
    end

    % CALCULATE ALTERNATIVE MTR SCHEDULE FROM PLANNER'S FOC.
    tax_marg_foc_rhs = (1+elas_uncomp)./elas_comp .* 1./(w.*pmf_over_bin_width) .* u_prime_c .* (marg_soc_value_above_w-total_marg_soc_value*(1-cdf));
    tax_marg_old = tax_marg;
    tax_marg_alternative = tax_marg_foc_rhs ./ (1+tax_marg_foc_rhs);

    % ADJUST MTR SCHEDULE HALF-WAY TO THE ALTERNATIVE MTR SCHEDULE, STORE
    % VALUES FOR THIS ITERATION, AND UPDATE VALUE FOR THE WHILE LOOP 
    % ARGUMENT.
    tax_marg = (tax_marg + tax_marg_alternative) ./ 2;
    max_percent_opt_tax_deviation = max(100*(tax_marg_alternative-tax_marg)./tax_marg);
    tax_marg_iters(:,loop+1) = tax_marg;
    l_iters(:,2*loop-1) = l;
    y_iters(:,2*loop-1) = y;


    % CALCULATE EACH WAGE'S TAX LIABILITY AT THE NEW MTR SCHEDULE. 
    [l, y] = FP_find_opt_l_(num_wages, transfer, tax_marg, w, guess_for_lowest_wage, lb, ub, options, gamma, alpha, sigma);
    for i=1:num_wages
        c(i) = FP_consump_(l(i), i, w, y, tax_marg, transfer);
    end
    tax_paid = y + transfer - c;
    l_iters(:,2*loop) = l;
    y_iters(:,2*loop) = y;
    
    % SAVE VALUES.
    gov_rev_iters(loop,1) = sum(tax_paid.*pmf);
    gov_surplus_iters(loop,1) = sum((tax_paid-transfer).*pmf);
    transfer_iters(loop,1) = transfer;

    % SET THE NEW TRANSFER TO EQUAL GOVERNMENT REVENUE. NO SCALING IS
    % NECESSARY BECAUSE THE TRANSFER IS PER-CAPITA. ALSO UPDATE VALUE FOR
    % THE WHILE LOOP ARGUMENT.
    transfer = gov_rev_iters(loop,1);
    gov_imbalance_percent_gni = 100*gov_surplus_iters(loop,1)/sum(y.*pmf);
    
end
% [LOOP END].


% CHECK THAT EACH i PREFERS HIS (c,y) BUNDLE TO ALL OTHER m's BUNDLES. 
% IC_check(i) = {u_i[choosing i's bundle]-u_i[choosing m's bundle]}
% EVERY ELEMENT IN IC_check SHOULD BE NONNEGATIVE. THIS IS USED BELOW.
for i=1:num_wages
    for m=1:num_wages
        IC_check((i-1)*num_wages+m) = ((c(i)^(1-gamma)-1)/(1-gamma)-alpha*l(i)^sigma/sigma)...
                                    - ((c(m)^(1-gamma)-1)/(1-gamma)-alpha*(y(m)/w(i))^sigma/sigma);
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DISPLAY RESULTS

% DISPLAY INDICATIONS OF SIMULATION SUCCESS.
disp ' '
disp ' '
disp ' '
disp '<<<<<<<<<<<<<<<<<<<<<<<<  INDICATIONS OF SIMULATION SUCCESS  >>>>>>>>>>>>>>>>>>>>>>>>'
disp '(1) Is y(w) non-deacreasing?  "1" means yes.'
disp '(2) Max IC violation: [utility from misrepresenting] - [utility from revealing type]' 
disp '(3) Min optimal marginal tax rate'
disp '(4) Max optimal marginal tax rate'
disp '(5) Slackness of the government BC: Gov budget imbalance as a percent of GNI'
disp '(6) Max percent deviation of final tax schedule from "optimal" tax schedule'
disp '(7) Transfer'
disp '(8) Total number loops run'

[1, (min(diff(y))>=0);
2, -min(IC_check);
3, min(tax_marg)
4, max(tax_marg)
5, gov_imbalance_percent_gni;
6, max_percent_opt_tax_deviation;
7, transfer;
8, loop]


% PLOT MTR VS. WAGE.
figure
plot(w,tax_marg)
title('Optimal MTR vs. Wage')
ylabel('MTR')
xlabel('Wage')
saveas(gcf,'MTR_v_Wage.fig')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SAVE LATEST OUTPUT AND CLOSE DIARY
save FP_MTR_sim.mat;
diary off;



