%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIXED-POINT MIRRLEES SIMULATIONS
%
% FUNCTION FOR FINDING OPTIMAL LABOR SUPPLY FOR ALL INDIVIDUALS
% FP_find_opt_l_.m
%
% Mankiw-Weinzierl-Yagan "Optimal Taxation in Theory and Practice"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [l, y] = FP_find_opt_l_(num_wages, transfer, tax_marg, w, guess_for_lowest_wage, lb, ub, options, gamma, alpha, sigma);


l = zeros(num_wages,1);
y = zeros(num_wages,1);
guess = guess_for_lowest_wage;

for i=1:num_wages
    l(i) = fmincon( 'FP_opt_l_obj_', guess, [],[],[],[], lb, ub, [], options, i, w, y, tax_marg, transfer, gamma, alpha, sigma);
    y(i) = w(i)*l(i);
    guess = l(i);
end


end