%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIXED-POINT MIRRLEES SIMULATIONS
%
% FUNCTION FOR CALCULATING CONSUMPTION FOR A GIVEN INDIVIDUAL
% FP_consump_.m
%
% Mankiw-Weinzierl-Yagan "Optimal Taxation in Theory and Practice"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [c_i] = FP_consump_(l_i, i, w, y, tax_marg, transfer);


y(i) = w(i)*l_i;

% FIND THE HIGHEST j SUCH THAT y(j) IS LESS THAN y(i). THIS IS AKIN TO 
% FINDING THE iTH'S PERSON'S TAX BRACKET j, GIVEN i'S INCOME. IN THIS
% EXERCISE, THERE ARE EXACTLY i TAX BRACKETS SINCE WE CALCULATE EACH
% PERSON'S LABOR SUPPLY AS IF HIS ASSIGNED MARGINAL TAX RATE IS THE
% TAX RATE THAT APPLIES TO ALL INCOMES EARNED ABOVE y(i-1), OR ABOVE 0 IF
% i EQUALS 1. NOTE THAT IF y(1:i-1) IS NOT MONOTONIC, THIS ALGORITHM PUTS i
% INTO THE LOWEST POSSIBLE TAX BRACKET.

j = 1;
while ( (j ~= i)  &&  (y(j) < y(i)) )
    j = j+1;
end

% CALCULATE TAX PAID BY THIS iTH PERSON GIVEN HIS TAX BRACKET.
if (j==1)
    tax_paid_i = tax_marg(1)*y(i);
elseif (j==2)
    tax_paid_i = tax_marg(1)*y(1) + tax_marg(2)*(y(i)-y(1));
else
    tax_paid_i = tax_marg(1)*y(1) + sum(tax_marg(2:j-1).*diff(y(1:j-1))) + tax_marg(j)*(y(i)-y(j-1));        
end

% CALCULATE RESULTING CONSUMPTION.
c_i = transfer + y(i) - tax_paid_i;


end